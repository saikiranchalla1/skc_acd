	var eventDetails = {
	    name: 'FEWB training',
	        date: '29/10/2014',
	        time: '10:40 am',
	        location:{
	        	address:"#122,Lavella Road",
	        	city:"noida",
	        	pin:"560078"
	        },
	        imageUrl: "img/html5_css3_js.jpg",
        	sessions:[
    	            {
    	             
    	                name: "training on the html5",
   	                   creator:"john",
   	                  duration:"2 hours",
   	                  details:"HTML5 is a core technology markup language of the Internet used for structuring and presenting content for the World Wide Web",
   	                  votes: john
    	            },
    	            {
    	                name: "training on the CSS3",
  	                  creator:"kevin",
  	                  duration:"4 hours",
  	                  details:"CSS3 is completely backwards-compatible with earlier versions of CSS",
  	                  votes:10
    	                
    	            },
    	            {
    	                name: "training on the javascript",
    	                creator: "doughlas",
    	                  duration:"8 hours",
    	                  details: "JavaScript is the programming language of HTML and the Web",
    	                  votes:30	  
    	            }]
		};
