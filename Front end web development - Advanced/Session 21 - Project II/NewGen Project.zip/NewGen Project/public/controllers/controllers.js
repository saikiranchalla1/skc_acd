function AppCtrl($scope){
$scope.setActive = function(type){
			$scope.destinationsActive = '';
			$scope.flightsActive = '';
			$scope.reservationsActive = '';

			$scope[type + 'Active'] = 'active';
		}
}