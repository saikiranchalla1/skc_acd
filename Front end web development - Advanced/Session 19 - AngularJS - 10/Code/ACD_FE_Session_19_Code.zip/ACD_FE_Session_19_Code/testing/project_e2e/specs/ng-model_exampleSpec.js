describe('testing localhost app',function(){
it('should add and test result',function(){
	browser.get('http://localhost/testingangular/src/ng-model_example.html');
	element(by.model('a')).sendKeys(24);
	element(by.model('b')).sendKeys(44);
	element(by.tagName('button')).click();
	expect(element(by.binding('result')).getText()).toEqual('68');
})
	
})