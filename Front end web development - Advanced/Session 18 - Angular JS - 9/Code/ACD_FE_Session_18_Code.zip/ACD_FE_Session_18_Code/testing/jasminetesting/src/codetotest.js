function AddTwoNumbers(a,b) {
  return a + b; //Function to return addition of two numbers a and b.
}
 
function MultiplyTwoNumbers(a,b) {
	  return a * b; //Function to return product of two numbers a and b.
}