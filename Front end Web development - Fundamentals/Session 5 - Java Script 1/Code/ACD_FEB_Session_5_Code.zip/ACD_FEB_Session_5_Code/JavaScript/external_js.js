
var operand1 = 10;
var operand2 = 20;
var result = operand1 * operand2;
alert(result);